# GameAssist ProGuard Rules
-keepattributes *Annotation*
-keep class com.gameassist.models.** { *; }
-keep class com.gameassist.GameAssistService { *; }
-keep class com.gameassist.MainActivity { *; }

# Keep coroutine suspend functions
-keepclassmembers class kotlinx.coroutines.** { *; }

# Note: android.accessibilityservice.** is already kept by the Android framework
# Removed overly broad -keep that unnecessarily increased APK size
