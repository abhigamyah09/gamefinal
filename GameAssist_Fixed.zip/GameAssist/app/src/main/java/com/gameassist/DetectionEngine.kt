package com.gameassist

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.util.Log
import com.gameassist.models.GameObject
import com.gameassist.models.ObjectType
import kotlin.math.abs

/**
 * HSV-based color detection engine.
 * Scans downscaled frames to find game objects (meteors, UFOs, phones, stars, player).
 *
 * Optimized for 4GB RAM budget phones:
 * - Grid scanning (every N pixels) instead of pixel-by-pixel
 * - HSV color space for robust detection despite glow effects
 * - MINIMUM object size filter to reject background noise
 * - Grid-based clustering O(n) instead of BFS O(n²) — prevents CRASH
 * - Game area ROI (Region of Interest) to exclude UI elements
 * - Reusable pixel buffer to prevent GC pressure
 */
class DetectionEngine(
    private val screenWidth: Int,
    private val screenHeight: Int,
    scanStep: Int = 4
) {

    companion object {
        private const val TAG = "DetectionEngine"

        // Minimum object size in pixels (on downscaled image)
        private const val MIN_OBJECT_WIDTH = 8
        private const val MIN_OBJECT_HEIGHT = 8

        // Game area ROI - exclude top UI and bottom nav
        private const val ROI_TOP_PERCENT = 0.12f
        private const val ROI_BOTTOM_PERCENT = 0.95f

        // Grid cell size for fast clustering (pixels)
        private const val GRID_CELL_SIZE = 12

        // Min pixels in a cluster to be considered an object
        private const val MIN_CLUSTER_SIZE = 5

        // Max pixels in a cluster (safety cap)
        private const val MAX_CLUSTER_SIZE = 600
    }

    // SCAN STEP: mutable for adaptive scaling
    var scanStep: Int = scanStep
        set(value) {
            field = value.coerceIn(2, 8)  // Clamp 2-8
            Log.d(TAG, "Scan step changed to $field")
        }

    // Adaptive scan top ratio (0.0 = top, 1.0 = bottom). Set by GameAssistService.
    var scanTopRatio: Float = ROI_TOP_PERCENT
        set(value) {
            field = value.coerceIn(0.05f, 0.80f)
            Log.d(TAG, "Scan top ratio changed to $field")
        }

    // HSV color ranges for each object type
    private data class HSVRange(
        val minH: Float, val maxH: Float,
        val minS: Float, val maxS: Float,
        val minV: Float, val maxV: Float
    )

    private val meteorRange = HSVRange(5f, 30f, 160f, 255f, 120f, 255f)
    private val ufoRange = HSVRange(190f, 230f, 100f, 255f, 80f, 220f)
    private val phoneRange = HSVRange(270f, 310f, 60f, 180f, 140f, 255f)
    private val starRange = HSVRange(0f, 360f, 0f, 50f, 200f, 255f)
    private val playerRange = HSVRange(310f, 345f, 120f, 255f, 100f, 255f)

    // ROI bounds
    private val roiTop: Int = (screenHeight * ROI_TOP_PERCENT).toInt()
    private val roiBottom: Int = (screenHeight * ROI_BOTTOM_PERCENT).toInt()
    private val playerScanTop: Int = (screenHeight * 0.75f).toInt()

    // Reusable HSV buffer (prevents GC allocations)
    // Thread safety: This class is designed for single-threaded use from the coroutine
    // processing loop. If concurrency changes, these must be wrapped in ThreadLocal.
    private val hsvBuffer = FloatArray(3)

    // Reusable pixel array (prevents allocation per frame)
    // Same thread-safety assumption as hsvBuffer above
    private var reusablePixels: IntArray? = null
    private var reusablePixelsSize: Int = 0

    // Background reference
    private var backgroundPixels: IntArray? = null
    private var backgroundWidth: Int = 0
    private var backgroundHeight: Int = 0

    /**
     * Optional: Capture background frame for subtraction.
     */
    fun captureBackground(bitmap: Bitmap) {
        backgroundWidth = bitmap.width
        backgroundHeight = bitmap.height
        backgroundPixels = IntArray(bitmap.width * bitmap.height)
        bitmap.getPixels(backgroundPixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
        Log.d(TAG, "Background captured: ${bitmap.width}x${bitmap.height}")
    }

    /**
     * Main detection method.
     */
    fun detectFrame(bitmap: Bitmap): List<GameObject> {
        val width = bitmap.width
        val height = bitmap.height

        // Reset background if dimensions changed
        if (backgroundPixels != null && (backgroundWidth != width || backgroundHeight != height)) {
            backgroundPixels = null
        }

        // Scale ROI — use adaptive scanTopRatio for scan window
        val scaledRoiTop = (scanTopRatio.toFloat() * height / screenHeight).toInt()
        val scaledRoiBottom = (roiBottom.toFloat() * height / screenHeight).toInt()
        val scaledPlayerTop = (playerScanTop.toFloat() * height / screenHeight).toInt()

        // Reuse pixel array to prevent GC pressure on 4GB phones
        val neededSize = width * height
        if (reusablePixels == null || reusablePixelsSize < neededSize) {
            reusablePixels = IntArray(neededSize)
            reusablePixelsSize = neededSize
        }
        val pixels = reusablePixels!!
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

        // Collect matches using grid-based spatial indexing (O(n) clustering)
        val meteorGrid = SpatialGrid(GRID_CELL_SIZE)
        val ufoGrid = SpatialGrid(GRID_CELL_SIZE)
        val phoneGrid = SpatialGrid(GRID_CELL_SIZE)
        val starGrid = SpatialGrid(GRID_CELL_SIZE)
        val playerGrid = SpatialGrid(GRID_CELL_SIZE)

        // Scan game area
        for (y in scaledRoiTop until scaledRoiBottom step scanStep) {
            for (x in 0 until width step scanStep) {
                val idx = y * width + x
                val pixel = pixels[idx]

                // Background subtraction
                if (backgroundPixels != null && idx < backgroundPixels!!.size) {
                    if (isSimilarPixel(pixel, backgroundPixels!![idx])) continue
                }

                Color.colorToHSV(pixel, hsvBuffer)
                val h = hsvBuffer[0]
                val s = hsvBuffer[1] * 255
                val v = hsvBuffer[2] * 255

                when {
                    isInRange(h, s, v, meteorRange) -> meteorGrid.add(x, y)
                    isInRange(h, s, v, ufoRange) -> ufoGrid.add(x, y)
                    isInRange(h, s, v, phoneRange) -> phoneGrid.add(x, y)
                    isInRange(h, s, v, starRange) -> starGrid.add(x, y)
                }
            }
        }

        // Scan player zone
        for (y in scaledPlayerTop until scaledRoiBottom step scanStep) {
            for (x in 0 until width step scanStep) {
                val idx = y * width + x
                Color.colorToHSV(pixels[idx], hsvBuffer)
                if (isInRange(hsvBuffer[0], hsvBuffer[1] * 255, hsvBuffer[2] * 255, playerRange)) {
                    playerGrid.add(x, y)
                }
            }
        }

        // Extract objects from grids
        val objects = mutableListOf<GameObject>()
        objects.addAll(gridToObjects(meteorGrid, ObjectType.METEOR, width, height))
        objects.addAll(gridToObjects(ufoGrid, ObjectType.UFO, width, height))
        objects.addAll(gridToObjects(phoneGrid, ObjectType.PHONE, width, height))
        objects.addAll(gridToObjects(starGrid, ObjectType.STAR, width, height))
        objects.addAll(gridToObjects(playerGrid, ObjectType.PLAYER, width, height))

        return objects
    }

    /**
     * Spatial grid for O(n) clustering — replaces O(n²) BFS.
     * Divides space into cells. Pixels in same or adjacent cells = same cluster.
     */
    private class SpatialGrid(private val cellSize: Int) {
        private val cells = mutableMapOf<Long, MutableList<Pair<Int, Int>>>()
        private val allPixels = mutableListOf<Pair<Int, Int>>()

        fun add(x: Int, y: Int) {
            if (allPixels.size >= MAX_CLUSTER_SIZE * 5) return  // Safety cap
            allPixels.add(x to y)
            val key = cellKey(x, y)
            cells.getOrPut(key) { mutableListOf() }.add(x to y)
        }

        private fun cellKey(x: Int, y: Int): Long {
            val cx = x / cellSize
            val cy = y / cellSize
            return (cx.toLong() shl 32) or (cy.toLong() and 0xFFFFFFFFL)
        }

        fun getClusters(): List<List<Pair<Int, Int>>> {
            if (allPixels.isEmpty()) return emptyList()
            val visited = mutableSetOf<Pair<Int, Int>>()
            val clusters = mutableListOf<List<Pair<Int, Int>>>()

            for (pixel in allPixels) {
                if (pixel in visited) continue

                // Flood fill using ONLY neighboring grid cells — O(n) not O(n²)
                val cluster = mutableListOf<Pair<Int, Int>>()
                val stack = ArrayDeque<Pair<Int, Int>>()
                stack.add(pixel)
                visited.add(pixel)

                while (stack.isNotEmpty()) {
                    val current = stack.removeLast()
                    cluster.add(current)
                    if (cluster.size >= MAX_CLUSTER_SIZE) break

                    val cx = current.first / cellSize
                    val cy = current.second / cellSize

                    // Check 3x3 neighboring cells only
                    for (dx in -1..1) {
                        for (dy in -1..1) {
                            val neighborKey = ((cx + dx).toLong() shl 32) or
                                    (((cy + dy).toLong()) and 0xFFFFFFFFL)
                            val neighborCell = cells[neighborKey] ?: continue
                            for (neighbor in neighborCell) {
                                if (neighbor !in visited) {
                                    visited.add(neighbor)
                                    stack.add(neighbor)
                                }
                            }
                        }
                    }
                }

                if (cluster.size >= MIN_CLUSTER_SIZE) {
                    clusters.add(cluster)
                }
            }

            return clusters
        }

        fun count(): Int = allPixels.size
    }

    /**
     * Convert spatial grid clusters to GameObjects.
     */
    private fun gridToObjects(
        grid: SpatialGrid,
        type: ObjectType,
        imageWidth: Int,
        imageHeight: Int
    ): List<GameObject> {
        val clusters = grid.getClusters()
        val objects = mutableListOf<GameObject>()

        for (cluster in clusters) {
            var minX = Int.MAX_VALUE
            var maxX = Int.MIN_VALUE
            var minY = Int.MAX_VALUE
            var maxY = Int.MIN_VALUE

            for ((px, py) in cluster) {
                if (px < minX) minX = px
                if (px > maxX) maxX = px
                if (py < minY) minY = py
                if (py > maxY) maxY = py
            }

            val objWidth = maxX - minX
            val objHeight = maxY - minY

            // Both dimensions must meet minimum — using || lets 1px×8px noise through
            if (objWidth >= MIN_OBJECT_WIDTH && objHeight >= MIN_OBJECT_HEIGHT) {
                val scaleX = screenWidth.toFloat() / imageWidth
                val scaleY = screenHeight.toFloat() / imageHeight

                objects.add(
                    GameObject(
                        type = type,
                        boundingBox = Rect(
                            (minX * scaleX).toInt(),
                            (minY * scaleY).toInt(),
                            (maxX * scaleX).toInt(),
                            (maxY * scaleY).toInt()
                        ),
                        centerX = ((minX + maxX) / 2 * scaleX).toInt(),
                        centerY = ((minY + maxY) / 2 * scaleY).toInt(),
                        width = (objWidth * scaleX).toInt(),
                        height = (objHeight * scaleY).toInt()
                    )
                )
            }
        }

        return objects
    }

    private fun isInRange(h: Float, s: Float, v: Float, range: HSVRange): Boolean {
        val inHue = if (range.minH > range.maxH) {
            h >= range.minH || h <= range.maxH
        } else {
            h in range.minH..range.maxH
        }
        return inHue && s in range.minS..range.maxS && v in range.minV..range.maxV
    }

    private fun isSimilarPixel(p1: Int, p2: Int): Boolean {
        val dr = abs(Color.red(p1) - Color.red(p2))
        val dg = abs(Color.green(p1) - Color.green(p2))
        val db = abs(Color.blue(p1) - Color.blue(p2))
        return dr < 15 && dg < 15 && db < 15
    }
}
